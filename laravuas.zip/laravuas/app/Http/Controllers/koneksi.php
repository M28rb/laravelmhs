<?php

session_start();

include('web.php');

$username     = $_POST['email'];
$password      = MD5($_POST['password']);

//query
$query  = "SELECT * FROM laravuas WHERE email='$email' AND password='$password'";
$result     = mysqli_query($connection, $query);
$num_row     = mysqli_num_rows($result);
$row         = mysqli_fetch_array($result);

if($num_row >=1) {
    
    echo "success";

    $_SESSION['name'] = $row['name'];
    $_SESSION['email']       = $row['email'];

} else {
    
    echo "error";

}

?>