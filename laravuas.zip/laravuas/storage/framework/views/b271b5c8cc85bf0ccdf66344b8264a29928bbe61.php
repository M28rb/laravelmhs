<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
      <h1 class="text-center mb-5">Data Mahasiswa</h1>
      <div class="card">
      <div class="card-body">
        <table class="table">
          <thead>
            <th>NIM</th>
            <th>Tanggal Lahir</th>
            <th>Alamat</th>
            <th>Prodi</th>
            <th>Phone</th>
</thead>
<tbody>
  <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nim => $hasil): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <tr>
  <th><?php echo e($hasil->nim); ?></th>
<td><?php echo e($hasil->tanggal_lahir); ?></td>
<td><?php echo e($hasil->Alamat); ?></td>
<td><?php echo e($hasil->prodi); ?></td>
<td><?php echo e($hasil->phone); ?></td>
<td> 
    <a href="" class="btn btn-success btn-sm">Edit</a>
    <button class="btn btn-danger btn-sm">Hapus</a>
</td>
</tr>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</div>
</div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH E:\File Laravel Lumen\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>