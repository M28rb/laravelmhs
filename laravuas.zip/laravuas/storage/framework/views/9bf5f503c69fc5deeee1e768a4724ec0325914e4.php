<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Template</title>
    <link href="views/profile.css" rel="stylesheet">
</head>

<body>
    <main class="wrapper">
        <div class="bg-effect-img" style="background-image: url(assets/img/bg-effect-1.png);">
            <div class="marquee">
                <h2>Hi, This is WebDevs</h2>
                <h2>Tapsi d'Souza Tapsi d'Souza</h2>
            </div>
        </div>
        <section id="home" data-scroll-index="0" class="home-section-03">
            <div class="container position-relative">
                <div class="row align-items-center min-vh-100 justify-content-center">
                    <div class="col-lg-6">
                        <div class="home-image">
                            <div class="home-image-in">
                                <img src="assets/img/song-listning.jpg" title="" alt="">
                            </div>
                        </div>
                        <div class="home-intro">
                            <h1>Sarah Safferty</h1>
                            <h2>I'm a <span id="type-it">Developer</span></h2>
                            <ul class="nav social-link">
                                <li>
                                    <a href="#"><i class="fab fa-twitter"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-instagram"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-facebook"></i></a>
                                </li>
                                <li>
                                    <a href="#"><i class="fab fa-pinterest"></i></a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php /**PATH E:\File Laravel Lumen\resources\views/profile.blade.php ENDPATH**/ ?>