<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ajax Example</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
    <div class="container">
        <h2>Ajax Example</h2>
        <button class="btn btn-primary" onclick="showAddStudentModal()">Add Student</button>
        <table class="table">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Konsentrasi</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Tanggal Lahir</th>
                    <th>Telp</th>
                    <th>Alamat</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="studentTableBody">
            </tbody>
        </table>
        <div class="modal" id="studentModal">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="studentModalLabel"></h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">
                        <form id="studentForm">
                            <input type="hidden" id="studentIndex">
                            <div class="form-group">
                                <label for="nimMahasiswa">NIM</label>
                                <input type="text" class="form-control" id="nimMahasiswa" required>
                            </div>
                            <div class="form-group">
                                <label for="namaMahasiswa">Nama</label>
                                <input type="text" class="form-control" id="namaMahasiswa" required>
                            </div>
                            <div class="form-group">
                                <label for="konsentrasiProdi">Konsentrasi</label>
                                <select class="form-control" id="konsentrasiProdi" required>
                                    <option value="Ilmu Komputer">Ilmu Komputer</option>
                                    <option value="Sistem Informasi">Sistem Informasi</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="phoneMahasiswa">Phone</label>
                                <input type="text" class="form-control" id="phoneMahasiswa" required>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary" id="saveButton" onclick="saveStudent()">Save</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function displayStudents() {
            $.ajax({
                url: 'Mahasiswa.php',
                method: 'GET',
                success: function (response) {
                    $('#studentTableBody').html(response);
                }
            });
        }

        function loadStudentData(index) {
            $.ajax({
                url: 'Mahasiswa.php',
                method: 'POST',
                data: {
                    'load_student_data': true,
                    'student_index': index
                },
                success: function (response) {
                    var student = JSON.parse(response);
                    $('#studentIndex').val(student.id);
                    $('#nimMahasiswa').val(student.nim);
                    $('#namaMahasiswa').val(student.nama);
                    $('#konsentrasiProdi').val(student.konsentrasi);
                    $('#phoneMahasiswa').val(student.phone);
                    $('#saveButton').text('Update');
                }
            });
        }

        function saveStudent() {
            var studentIndex = $('#studentIndex').val();
            var nim = $('#nimMahasiswa').val();
            var nama = $('#namaMahasiswa').val();
            var konsentrasi = $('#konsentrasiProdi').val();
            var phone = $('#phoneMahasiswa').val();
            $.ajax({
                url: 'students.php',
                method: 'POST',
                data: {
                    'save_student_data': true,
                    'student_index': studentIndex,
                    'nim': nim,
                    'nama': nama,
                    'konsentrasi': konsentrasi,
                    'phone': phone
                },
                success: function (response) {
                    displayStudents();
                    $('#studentModal').modal('hide');
                }
            });
        }

        function deleteStudent(index) {
            $.ajax({
                url: 'students.php',
                method: 'POST',
                data: {
                    'delete_student_data': true,
                    'student_index': index
                },
                success: function (response) {
                    displayStudents();
                }
            });
        }

        function showAddStudentModal() {
            $('#studentModalLabel').text('Add Student');
            $('#saveButton').text('Save');
            $('#studentModal').modal('show');
        }

        $(document).ready(function () {
            displayStudents();
        });
    </script>
</body>
</html><?php /**PATH E:\File Laravel Lumen\resources\views/mahasiswa.blade.php ENDPATH**/ ?>