<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Data CRUD</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .modal-content {
            max-width: 500px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Mahasiswa</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Tgl Lahir</th>
                    <th>Telp</th>
                    <th>Alamat</th>
                    <th>Prodi</th>
                    <th>Konsentrasi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="studentTableBody">
                <!-- Student data will be dynamically inserted here -->
            </tbody>
        </table>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="studentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="studentModalLabel">Mahasiswa</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Sample data array to simulate a database
        let students = [
            {
      //
            }
        ];

        // Function to display student data in the table
        function displayStudents() {
            const studentTableBody = document.getElementById('studentTableBody');
            studentTableBody.innerHTML = '';
            students.forEach((student, index) => {
                studentTableBody.innerHTML += `
                    <tr>
                        <td>${index + 1}</td>
                        <td><a href="#" data-toggle="modal" data-target="#studentModal" onclick="loadStudentData(${index})">${student.nim}</a></td>
                        <td>${student.nama}</td>
                        <td>${student.email}</td>
                        <td>${student.tglLahir}</td>
                        <td>${student.telp}</td>
                        <td>${student.alamat}</td>
                        <td>${student.prodi}</td>
                        <td>${student.konsentrasi}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="loadStudentData(${index})" data-toggle="modal" data-target="#studentModal">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStudent(${index})">Delete</button>
                        </td>
                    </tr>
                `;
            });
        }

        
        // Function to save or update student data
        function saveStudent() {
            const index = document.getElementById('studentIndex').value;
            const nim = document.getElementById('nimMahasiswa').value;
            const nama = document.getElementById('namaMahasiswa').value;
            const email = document.getElementById('electronikMail').value;
            const tgllahir = document.getElementById('tanggalLahir').value;
            const telp = document.getElementById('phoneMahasiswa').value;
            const alamat = document.getElementById('alamatLengkap').value;
            const prodi = document.getElementById('programStudi').value;
            const konsentrasi = document.getElementById('konsentrasiJurusan').value;

            const student = {
                nim,
                nama,
                email,
                tgllahir,
                telp,
                alamat,
                prodi,
                konsentrasi,
            };

            if (index === '') {
                // Add new student
                students.push(student);
            } else {
                // Update existing student
                students[index] = student;
            }

            $('#studentModal').modal('hide');
            displayStudents();
        }

        // Function to delete a student
        function deleteStudent(index) {
            students.splice(index, 1);
            displayStudents();
        }

        // Initial display of students
        displayStudents();
    </script>
</body>
</html>