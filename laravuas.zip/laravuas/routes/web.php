<?php

/** @var \Laravel\Lumen\Routing\Router $router */

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/

$router->get('/phpversion', function () use ($router) {
    return $router->app->version();
});
$router->get('/', function () use ($router) {
    return view('welcome');
});

$router->get('/register', function () use ($router) {
    return view('register');
});

$router->get('/registeradmin', function () use ($router) {
    return view('registeradmin');
});

$router->get('/login', function () use ($router) {
    return view('login');
});

$router->get('/loginadmin', function () use ($router) {
    return view('loginadmin');
});

$router->get('/profile', function () use ($router) {
    return view('profile');
});

$router->get('/profileadmin', function () use ($router) {
    return view('profileadmin');
});

$router->get('/dashboard', function () use ($router) {
    return view('dashboard');
});

$router->get('/dashboardadmin', function () use ($router) {
    return view('dashboardadmin');
});

$router->get('/mahasiswa', function () use ($router) {
    return view('mahasiswa');
});

$router->get('/mahasiswaadmin', function () use ($router) {
    return view('mahasiswaadmin');
});

$router->get('/logout', function () use ($router) {
    return view('logout');
});

$router->get('/logoutadmin', function () use ($router) {
    return view('logoutadmin');
});

$router->group(['prefix' => 'api'], function () use ($router) {
    $router->post('/register', 'AuthController@register');
    $router->post('/registeradmin', 'AuthController@registeradmin');
    $router->post('/login', 'AuthController@login');
    $router->post('/loginadmin', 'AuthController@loginadmin');
   

    $router->group(['middleware' => 'auth'], function () use ($router) {
        $router->post('/logout', 'AuthController@logout');
        $router->post('/logoutadmin', 'AuthController@logoutadmin');
        $router->get('/posts', 'PostController@index');
        $router->post('/posts', 'PostController@store');
        $router->put('/posts/{id}', 'PostController@update');
        $router->delete('/posts/{id}', 'PostController@destroy');
        $router->get('/mahasiswa', 'MahasiswaController@index');
        $router->get('/mahasiswaadmin', 'MahasiswaController@index'); 

    
    
        //profil user
        $router->get('/userprofile', 'AuthController@userprofile');
    });
    
});
