<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
<div class="container" style="margin-top: 50px">
      <div class="row">
        
          <div class="col-md-3">
            <ul class="list-group">
              <li class="list-group-item active">MAIN MENU</li>
              <a href="{{ url('/dashboardadmin') }}" class="list-group-item" style="color: #212529;">Dashboard Admin</a>
              <a href="{{ url('/profileadmin') }}" class="list-group-item" style="color: #212529;">Profile Admin</a>
              <a href="{{ url('/mahasiswaadmin') }}" class="list-group-item" style="color: #212529;">List Mahasiswa</a>
              <a href="{{ url('/logoutadmin') }}" class="list-group-item" style="color: #212529;">Logout</a>
            </ul>
          </div>

          <div class="col-md-9">
            <div class="card">
              <div class="card-body">
                <label>PROFILE ADMIN</label>
                <hr>
                    </div>
                    <div class="card-body">
                        <ul class="list-group">
                            <li class="list-group-item">Name: <span id="profile-name"></span></li>
                            <li class="list-group-item">Email: <span id="profile-email"></span></li>
                            <li class="list-group-item">Aksi: <span id="profile-aksi"></span></li>
                            <a href="" class="btn btn-success btn-sm">Edit</a>
                            <!-- Add more profile information here -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script>
        
        $(document).ready(function(){
            $.ajax({
                url: "/api/userprofile",
                type: "GET",
                headers: {
                    "Authorization": "Bearer " + localStorage.getItem("token")
                },
                success:function(response){
                    $('#profile-name').text(response.name);
                    $('#profile-email').text(response.email);
                    // Add more profile information here
                },
                error:function(response){
                    alert("Failed to load profile data");
                }
            });
        });
    </script>
</body>
</html>