<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
    <div class="container mt-5">
      <h1 class="text-center mb-5">Data Mahasiswa</h1>
      <div class="card">
      <div class="card-body">
        <table class="table">
          <thead>
          <th>No</th>
          <th>NIM</th>
          <th>Nama</th>
          <th>Email</th>
          <th>Tgl Lahir</th>
          <th>Telp</th>
          <th>Alamat</th>
          <th>Prodi</th>
          <th>Konsentrasi</th>
          <th>Aksi</th>
</thead>
<tbody>
  @foreach ($mahasiswa as $nim => $hasil)
  <tr>
  <th>{{ $hasil->no }}</th>
  <th>{{ $hasil->nim }}</th>
<td>{{ $hasil->email }}</td>
<td>{{ $hasil->tgllahir }}</td>
<td>{{ $hasil->telp }}</td>
<td>{{ $hasil->Alamat }}</td>
<td>{{ $hasil->prodi }}</td>
<td>{{ $hasil->konsentrasi }}</td>
<td>{{ $hasil->aksi }}</td>
<td> 
    <a href="" class="btn btn-success btn-sm">Edit</a>
    <button class="btn btn-danger btn-sm">Hapus</a>
</td>
</tr>
  @endforeach
</tbody>
</div>
</div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>