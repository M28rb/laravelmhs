<?php
 
namespace App\Http\Controllers;
 
use Illuminate\Http\Request;
use Auth;
 
class UserController extends Controller
{

    
    public function login()
    {
        return view('login');
    }
    
    public function loginadmin()
    {
        return view('loginadmin');
    }
    
    public function check(Request $request)
    {  
        $email = $request->email;
        $pass  = $request->password;
 
        if (auth()->attempt(array('email' => $email, 'password' => $pass)))
        {
            return response()->json([ [1] ]);
        } 
        else
         {  
            return response()->json([ [3] ]);
         }  
        }
 
    public function home()
    {
        return view('home');
    }
    
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->flush();
        return redirect('/');
    }

    public function logoutadmin(Request $request)
    {
        Auth::logoutadmin();
        $request->session()->flush();
        return redirect('/');
    }
}