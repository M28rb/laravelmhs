<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\mahasiswa;


class MahasiswaController extends Controller
{
public function index()
{
   return view('mahasiswa.index')->with([
      'mahasiswa'=> mahasiswa::all(),
   ]);
}
}