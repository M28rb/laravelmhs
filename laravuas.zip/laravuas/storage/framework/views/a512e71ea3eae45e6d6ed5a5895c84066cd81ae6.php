<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Data CRUD</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        .modal-content {
            max-width: 500px;
            margin: auto;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Mahasiswa</h2>
        <button class="btn btn-primary mb-3" onclick="showAddStudentModal()">Tambah Baru</button>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>No</th>
                    <th>NIM</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Tgl Lahir</th>
                    <th>Telp</th>
                    <th>Alamat</th>
                    <th>Prodi</th>
                    <th>Konsentrasi</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody id="studentTableBody">
                <!-- Student data will be dynamically inserted here -->
            </tbody>
        </table>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="studentModal" tabindex="-1" aria-labelledby="studentModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="studentModalLabel">Mahasiswa</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="studentForm">
                        <input type="hidden" id="studentIndex">
                        <div class="form-group">
                            <label for="nimMahasiswa">NIM Mahasiswa</label>
                            <input type="text" class="form-control" id="nimMahasiswa">
                        </div>
                        <div class="form-group">
                            <label for="namaMahasiswa">Nama Mahasiswa</label>
                            <input type="text" class="form-control" id="namaMahasiswa">
                        </div>
                        <div class="form-group">
                            <label for="electronikMail">Electronik Mail</label>
                            <input type="text" class="form-control" id="electronikMail">
                        </div>
                        <div class="form-group">
                            <label for="tanggalLahir">Tanggal Lahir</label>
                            <input type="date" class="form-control" id="tanggalLahir">
                        </div>
                        <div class="form-group">
                            <label for="phoneMahasiswa">Phone / No WA</label>
                            <input type="text" class="form-control" id="phoneMahasiswa">
                        </div>
                        <div class="form-group">
                            <label for="alamatLengkap">Alamat Lengkap</label>
                            <input type="text" class="form-control" id="phoneMahasiswa">
                        </div>
                        <div class="form-group">
                            <label for="programStudi">Program Studi</label>
                            <select class="form-control" id="programStudi">
                                <option>Ilmu Komputer (F. Ilmu Komputer)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="konsentrasiJurusan">Konsentrasi yang dipilih</label>
                            <input type="text" class="form-control" id="konsentrasiJurusan">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="saveButton" onclick="saveStudent()">Save changes</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script>
        // Sample data array to simulate a database
        let students = [
            {
      //
            }
        ];

        // Function to display student data in the table
        function displayStudents() {
            const studentTableBody = document.getElementById('studentTableBody');
            studentTableBody.innerHTML = '';
            students.forEach((student, index) => {
                studentTableBody.innerHTML += `
                    <tr>
                        <td>${index + 1}</td>
                        <td><a href="#" data-toggle="modal" data-target="#studentModal" onclick="loadStudentData(${index})">${student.nim}</a></td>
                        <td>${student.nama}</td>
                        <td>${student.email}</td>
                        <td>${student.tglLahir}</td>
                        <td>${student.telp}</td>
                        <td>${student.alamat}</td>
                        <td>${student.prodi}</td>
                        <td>${student.konsentrasi}</td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="loadStudentData(${index})" data-toggle="modal" data-target="#studentModal">Edit</button>
                            <button class="btn btn-danger btn-sm" onclick="deleteStudent(${index})">Delete</button>
                        </td>
                    </tr>
                `;
            });
        }

        // Function to load student data into the modal form
        function loadStudentData(index) {
            const student = students[index];
            document.getElementById('studentIndex').value = index;
            document.getElementById('nimMahasiswa').value = student.nim;
            document.getElementById('namaMahasiswa').value = student.nama;
            document.getElementById('electronikMail').value = student.email;
            document.getElementById('tanggalLahir').value = student.tglLahir;
            document.getElementById('phoneMahasiswa').value = student.telp;
            document.getElementById('alamatLengkap').value = student.alamat;
            document.getElementById('programStudi').value = student.prodi;
            document.getElementById('konsentrasiProdi').value = student.konsentrasi;
            document.getElementById('studentModalLabel').innerText = 'Edit Mahasiswa';
            document.getElementById('saveButton').innerText = 'Update';
        }

        // Function to show the modal for adding a new student
        function showAddStudentModal() {
            document.getElementById('studentForm').reset();
            document.getElementById('studentIndex').value = '';
            document.getElementById('studentModalLabel').innerText = 'Tambah Mahasiswa';
            document.getElementById('saveButton').innerText = 'Save';
            $('#studentModal').modal('show');
        }

        // Function to save or update student data
        function saveStudent() {
            const index = document.getElementById('studentIndex').value;
            const nim = document.getElementById('nimMahasiswa').value;
            const nama = document.getElementById('namaMahasiswa').value;
            const email = document.getElementById('electronikMail').value;
            const tgllahir = document.getElementById('tanggalLahir').value;
            const telp = document.getElementById('phoneMahasiswa').value;
            const alamat = document.getElementById('alamatLengkap').value;
            const prodi = document.getElementById('programStudi').value;
            const konsentrasi = document.getElementById('konsentrasiJurusan').value;

            const student = {
                nim,
                nama,
                email,
                tgllahir,
                telp,
                alamat,
                prodi,
                konsentrasi,
                nimmahasiswa:'',
                namanamamahasiswa:'',
                electronikmail:'',
                tanggallahir:'',
                phonemahasiswa:'',
                alamatlengkap:'',
                programstudi:'',
                konsentrasijurusan:'',
            };

            if (index === '') {
                // Add new student
                students.push(student);
            } else {
                // Update existing student
                students[index] = student;
            }

            $('#studentModal').modal('hide');
            displayStudents();
        }

        // Function to delete a student
        function deleteStudent(index) {
            students.splice(index, 1);
            displayStudents();
        }

        // Initial display of students
        displayStudents();
    </script>
</body>
</html><?php /**PATH C:\xampp\htdocs\laravuas\resources\views/mahasiswa.blade.php ENDPATH**/ ?>