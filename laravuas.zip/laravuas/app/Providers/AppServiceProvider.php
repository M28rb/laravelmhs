<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
            return view('register');
        }
            
        public function check(Request $request)
        {  
            $name= $request->name;
            $email= $request->email;
            $pass  = $request->password;
     
            if (auth()->attempt(array('email' => $email, 'email' => $email, 'password' => $pass)))
            {
                return response()->json([ [1] ]);
            } 
            else
             {  
                return response()->json([ [3] ]);
             }  
            }
    }
